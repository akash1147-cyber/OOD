
class Reader extends LibraryMember {
    public Reader(String name, int memberId) {
        super(name, memberId);
    }

    @Override
    public void performAction() {
        System.out.println("Reader " + getName() + " is reading a book.");
    }
}
