
class LibraryAssistance extends LibraryMember {
    public LibraryAssistance(String name, int memberId) {
        super(name, memberId);
    }

    @Override
    public void performAction() {
        System.out.println("Library assistant " + getName() + " is assisting a reader.");
    }
}
