import java.util.Scanner;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the capacity of the library: ");
        int capacity = scanner.nextInt();

        Library library = new Library(capacity);

        while (true) {
            System.out.println("\nEnter your choice:");
            System.out.println("1. Add a book");
            System.out.println("2. Display all books");
            System.out.println("3. Perform Member Action");
            System.out.println("4. Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    scanner.nextLine();
                    System.out.print("Enter book title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter book author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter publication year: ");
                    int year = scanner.nextInt();

                    Book newBook = new Book(title, author, year);
                    library.addBook(newBook);
                    break;

                case 2:
                    library.displayBooks();
                    break;

                case 3:

                    scanner.nextLine();
                    System.out.print("Enter member type (Reader/Assistance): ");
                    String memberType = scanner.nextLine();
                    System.out.print("Enter member name: ");
                    String memberName = scanner.nextLine();
                    System.out.print("Enter member ID: ");
                    int memberId = scanner.nextInt();

                    LibraryMember member;
                    if (memberType.equalsIgnoreCase("Reader")) {
                        member = new Reader(memberName, memberId);
                    } else if (memberType.equalsIgnoreCase("Assistance")) {
                        member = new LibraryAssistance(memberName, memberId);
                    } else {
                        System.out.println("Invalid member type.");
                        break;
                    }
                    member.performAction();
                    break;

                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
